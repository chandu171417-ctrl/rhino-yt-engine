# 🚀 RhinoAlgo YT Engine — Setup Guide

## What this does
- Connects to your real YouTube channel via Google OAuth
- Shows live analytics: subscribers, views, SEO score per video
- AI generates optimized titles, tags, descriptions for each video
- **One-tap PUBLISH** buttons send changes directly to YouTube

---

## STEP 1 — Google Cloud Setup (15 mins, one time)

### 1.1 Create Project
1. Go to https://console.cloud.google.com
2. Click "Select a project" → "New Project"
3. Name it: `RhinoAlgo YT Engine` → Create

### 1.2 Enable YouTube API
1. Go to "APIs & Services" → "Library"
2. Search "YouTube Data API v3" → Click → **ENABLE**

### 1.3 Create OAuth Credentials
1. Go to "APIs & Services" → "Credentials"
2. Click "+ CREATE CREDENTIALS" → "OAuth client ID"
3. If prompted, configure OAuth consent screen first:
   - User Type: External
   - App name: RhinoAlgo YT Engine
   - Add your email
   - Scopes: add `youtube` and `youtube.force-ssl`
   - Test users: add your Google account email
4. Back to Create OAuth client ID:
   - Application type: **Web application**
   - Name: RhinoAlgo YT Engine
   - Authorized redirect URIs: Add both:
     - `http://localhost:3000/auth/callback` (for local testing)
     - `https://YOUR-APP.vercel.app/auth/callback` (after deploy)
5. Copy the **Client ID** and **Client Secret**

---

## STEP 2 — Deploy to Vercel (Free, 5 mins)

### 2.1 Create GitHub repo
1. Go to https://github.com → New repository
2. Name: `rhinoalgo-yt-engine` → Create
3. Upload all these files to the repo

### 2.2 Deploy on Vercel
1. Go to https://vercel.com → Sign up with GitHub
2. "New Project" → Import your GitHub repo
3. Click Deploy (it'll fail first — that's ok, we need to add env vars)

### 2.3 Set Environment Variables in Vercel
Go to your project → Settings → Environment Variables → Add:

| Name | Value |
|------|-------|
| `GOOGLE_CLIENT_ID` | Your OAuth Client ID |
| `GOOGLE_CLIENT_SECRET` | Your OAuth Client Secret |
| `BASE_URL` | `https://YOUR-APP-NAME.vercel.app` |
| `SESSION_SECRET` | Any long random string e.g. `rhinoalgo_abc123xyz789` |
| `ANTHROPIC_API_KEY` | Your Claude API key (from console.anthropic.com) |

4. Go to Deployments → Redeploy

### 2.4 Update OAuth redirect URI
Go back to Google Cloud Console → Credentials → your OAuth client
Add: `https://YOUR-APP-NAME.vercel.app/auth/callback`

---

## STEP 3 — Use the App

1. Open your Vercel URL
2. Click "LOGIN WITH GOOGLE"
3. Sign in with your YouTube channel's Google account
4. Grant permission
5. Done! Your channel data loads automatically.

---

## Features
- **📹 Videos tab** — All videos with SEO score. Click any video to expand.
  - 📊 SEO Score breakdown
  - 🎯 Generate AI titles → tap one → click "PUBLISH TITLE TO YOUTUBE"
  - 🏷 Generate AI tags → click "PUBLISH TAGS TO YOUTUBE"
  - 📝 Generate AI description → click "PUBLISH DESCRIPTION TO YOUTUBE"
- **💡 Insights** — Channel growth recommendations
- **🔍 Keywords** — Research any keyword for your niche
- **🔬 Audit** — Full channel health report
- **⚡ Generate** — Content package for new videos

---

## Local Testing (optional)
```bash
npm install
cp .env.example .env
# Fill in .env with your credentials (use http://localhost:3000 as BASE_URL)
npm start
# Open http://localhost:3000
```

---

## Troubleshooting
- **"Access blocked"** — Add your email to OAuth consent screen test users
- **"redirect_uri_mismatch"** — Make sure your Vercel URL is in OAuth redirect URIs
- **Videos not updating** — Check YouTube quota (10,000 units/day free)
- **AI not generating** — Check ANTHROPIC_API_KEY is set in Vercel env vars
